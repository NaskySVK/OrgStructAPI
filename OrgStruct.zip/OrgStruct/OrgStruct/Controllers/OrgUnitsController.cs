﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrgStruct.Models;

namespace OrgStruct.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrgUnitsController : ControllerBase
    {
        private readonly OrgStructdbContext _context;

        public OrgUnitsController(OrgStructdbContext context)
        {
            _context = context;
        }

        // GET: api/OrgUnits
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrgUnit>>> GetOrgUnits()
        {
            return await _context.OrgUnits.ToListAsync();
        }

        // GET: api/OrgUnits/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OrgUnit>> GetOrgUnit(int id)
        {
            var orgUnit = await _context.OrgUnits.FindAsync(id);

            if (orgUnit == null)
            {
                return NotFound();
            }

            return orgUnit;
        }

        // PUT: api/OrgUnits/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOrgUnit(int id, OrgUnit orgUnit)
        {
            if (id != orgUnit.UnitId)
            {
                return BadRequest();
            }

            _context.Entry(orgUnit).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrgUnitExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/OrgUnits
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<OrgUnit>> PostOrgUnit(OrgUnit orgUnit)
        {
            _context.OrgUnits.Add(orgUnit);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrgUnit", new { id = orgUnit.UnitId }, orgUnit);
        }

        // DELETE: api/OrgUnits/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOrgUnit(int id)
        {
            var orgUnit = await _context.OrgUnits.FindAsync(id);
            if (orgUnit == null)
            {
                return NotFound();
            }

            _context.OrgUnits.Remove(orgUnit);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool OrgUnitExists(int id)
        {
            return _context.OrgUnits.Any(e => e.UnitId == id);
        }
    }
}
