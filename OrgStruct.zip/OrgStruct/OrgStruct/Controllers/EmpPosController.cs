﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrgStruct.Models;

namespace OrgStruct.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpPosController : ControllerBase
    {
        private readonly OrgStructdbContext _context;

        public EmpPosController(OrgStructdbContext context)
        {
            _context = context;
        }

        // GET: api/EmpPos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmpPos>>> GetEmpPos()
        {
            return await _context.EmpPos.ToListAsync();
        }

        // GET: api/EmpPos/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EmpPos>> GetEmpPos(int id)
        {
            var empPos = await _context.EmpPos.FindAsync(id);

            if (empPos == null)
            {
                return NotFound();
            }

            return empPos;
        }

        // PUT: api/EmpPos/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEmpPos(int id, EmpPos empPos)
        {
            if (id != empPos.EmpPosId)
            {
                return BadRequest();
            }

            _context.Entry(empPos).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmpPosExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EmpPos
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<EmpPos>> PostEmpPos(EmpPos empPos)
        {
            _context.EmpPos.Add(empPos);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEmpPos", new { id = empPos.EmpPosId }, empPos);
        }

        // DELETE: api/EmpPos/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmpPos(int id)
        {
            var empPos = await _context.EmpPos.FindAsync(id);
            if (empPos == null)
            {
                return NotFound();
            }

            _context.EmpPos.Remove(empPos);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EmpPosExists(int id)
        {
            return _context.EmpPos.Any(e => e.EmpPosId == id);
        }
    }
}
