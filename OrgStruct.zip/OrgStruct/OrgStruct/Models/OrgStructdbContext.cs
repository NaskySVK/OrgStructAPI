﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace OrgStruct.Models;

public partial class OrgStructdbContext : DbContext
{
    public OrgStructdbContext()
    {
    }

    public OrgStructdbContext(DbContextOptions<OrgStructdbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Emp> Emps { get; set; }

    public virtual DbSet<EmpPos> EmpPos { get; set; }

    public virtual DbSet<OrgUnit> OrgUnits { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=OrgStructdb");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Emp>(entity =>
        {
            entity.HasKey(e => e.EmpId).HasName("PK__Emp__1299A8614AC55BA4");

            entity.ToTable("Emp");

            entity.Property(e => e.EmpId).HasColumnName("emp_id");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .HasColumnName("email");
            entity.Property(e => e.FirstName)
                .HasMaxLength(100)
                .HasColumnName("first_name");
            entity.Property(e => e.LastName)
                .HasMaxLength(100)
                .HasColumnName("last_name");
            entity.Property(e => e.Phone)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("phone");
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("title");
        });

        modelBuilder.Entity<EmpPos>(entity =>
        {
            entity.HasKey(e => e.EmpPosId).HasName("PK__EmpPos__6A2BF300394C2417");

            entity.HasIndex(e => new { e.EmpId, e.UnitId }, "UQ_EmpPos").IsUnique();

            entity.Property(e => e.EmpPosId).HasColumnName("emp_pos_id");
            entity.Property(e => e.EmpId).HasColumnName("emp_id");
            entity.Property(e => e.PosName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("pos_name");
            entity.Property(e => e.UnitId).HasColumnName("unit_id");

            //entity.HasOne(d => d.Emp).WithMany(p => p.EmpPos)
            //    .HasForeignKey(d => d.EmpId)
            //    .HasConstraintName("FK__EmpPos__emp_id__5629CD9C");

            //entity.HasOne(d => d.Unit).WithMany(p => p.EmpPos)
            //    .HasForeignKey(d => d.UnitId)
            //    .HasConstraintName("FK__EmpPos__unit_id__571DF1D5");
        });

        modelBuilder.Entity<OrgUnit>(entity =>
        {
            entity.HasKey(e => e.UnitId).HasName("PK__OrgUnit__D3AF5BD75B979B10");

            entity.ToTable("OrgUnit", tb =>
                {
                    tb.HasTrigger("trg_AfterInsertOrgUnit");
                    tb.HasTrigger("trg_DeleteOrgUnit");
                });

            entity.Property(e => e.UnitId).HasColumnName("unit_id");
            entity.Property(e => e.Code)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("code");
            entity.Property(e => e.DirectorId).HasColumnName("director_id");
            entity.Property(e => e.Level).HasColumnName("level");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
            entity.Property(e => e.ParentUnitId).HasColumnName("parent_unit_id");

            //entity.HasOne(d => d.Director).WithMany(p => p.OrgUnits)
            //    .HasForeignKey(d => d.DirectorId)
            //    .OnDelete(DeleteBehavior.ClientSetNull)
            //    .HasConstraintName("FK__OrgUnit__directo__52593CB8");

            //entity.HasOne(d => d.ParentUnit).WithMany(p => p.InverseParentUnit)
            //    .HasForeignKey(d => d.ParentUnitId)
            //    .HasConstraintName("FK__OrgUnit__parent___5165187F");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
