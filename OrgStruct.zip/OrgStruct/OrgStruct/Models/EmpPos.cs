﻿using System;
using System.Collections.Generic;

namespace OrgStruct.Models;

public partial class EmpPos
{
    public int EmpPosId { get; set; }

    public int EmpId { get; set; }

    public int UnitId { get; set; }

    public string PosName { get; set; } = null!;

    //public virtual Emp Emp { get; set; } = null!;

    //public virtual OrgUnit Unit { get; set; } = null!;
}
