﻿using System;
using System.Collections.Generic;

namespace OrgStruct.Models;

public partial class Emp
{
    public int EmpId { get; set; }

    public string? Title { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public string Email { get; set; } = null!;

    //public virtual ICollection<EmpPos> EmpPos { get; set; } = new List<EmpPos>();

    //public virtual ICollection<OrgUnit> OrgUnits { get; set; } = new List<OrgUnit>();
}
