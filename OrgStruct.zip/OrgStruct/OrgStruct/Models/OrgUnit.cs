﻿using System;
using System.Collections.Generic;

namespace OrgStruct.Models;

public partial class OrgUnit
{
    public int UnitId { get; set; }

    public string Name { get; set; } = null!;

    public string Code { get; set; } = null!;

    public int? ParentUnitId { get; set; }

    public int DirectorId { get; set; }

    public int Level { get; set; }

    //public virtual Emp Director { get; set; } = null!;

    //public virtual ICollection<EmpPos> EmpPos { get; set; } = new List<EmpPos>();

    //public virtual ICollection<OrgUnit> InverseParentUnit { get; set; } = new List<OrgUnit>();

    //public virtual OrgUnit? ParentUnit { get; set; }
}
